import math
import sys
# 可以从父目录下查找模块
sys.path.append('../')

# from model.MDT.MDT import mdt_s_sm as train_model
# from model.MDT.MDT2 import mdt_s_sm as train_model
# from model.MDT.MDT3 import mdt_s_sm as train_model
from model.MDT.MDT4 import mdt12 as train_model
# from model.T2T.T2T import T2t_vit_7 as train_model
# from model.Resnet.resnet import resnet18 as train_model
# from model.Swin.swin_transformer import swin_small_patch4_window7_224 as train_model
# from model.ViT.ViT import vit_base_patch16_224 as train_model
# from model.TNT.tnt import tnt_s_patch16_224 as train_model
# from model.Swin.swin_transformer_v2 import swin_v2 as train_model

import os.path
import time
from datetime import datetime
from openpyxl import Workbook
from tqdm import tqdm
import argparse
import matplotlib
# matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

import thop
import torch
import torchvision.transforms
import torch.utils.data as data
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast

def data_getter(dataset_root, transform_train, transform_test, batch_size, dataset_name):
    if dataset_name == 'cifar-10':
        # 训练集
        train_dataset = torchvision.datasets.CIFAR10(
            root=dataset_root, train=True, download=False, transform=transform_train)
        train_dataloader = data.DataLoader(
            train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

        # 测试集
        test_dataset = torchvision.datasets.CIFAR10(
            root=dataset_root, train=False, download=False, transform=transform_test)
        test_dataloader = data.DataLoader(
            test_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
        num_classes = len(train_dataset.classes)
    elif dataset_name == 'cifar-100':
        # 训练集
        train_dataset = torchvision.datasets.CIFAR100(
            root=dataset_root, train=True, download=False, transform=transform_train)
        train_dataloader = data.DataLoader(
            train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

        # 测试集
        test_dataset = torchvision.datasets.CIFAR100(
            root=dataset_root, train=False, download=False, transform=transform_test)
        test_dataloader = data.DataLoader(
            test_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
        num_classes = len(train_dataset.classes)
    elif dataset_name == 'mnist':
        # 训练集
        train_dataset = torchvision.datasets.MNIST(
            root=dataset_root, train=True, download=False, transform=transform_train)
        train_dataloader = data.DataLoader(
            train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

        # 测试集
        test_dataset = torchvision.datasets.MNIST(
            root=dataset_root, train=False, download=False, transform=transform_test)
        test_dataloader = data.DataLoader(
            test_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
        num_classes = len(train_dataset.classes)
    elif dataset_name == 'fashion-mnist':
        # 训练集
        train_dataset = torchvision.datasets.FashionMNIST(
            root=dataset_root, train=True, download=False, transform=transform_train)
        train_dataloader = data.DataLoader(
            train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

        # 测试集
        test_dataset = torchvision.datasets.FashionMNIST(
            root=dataset_root, train=False, download=False, transform=transform_test)
        test_dataloader = data.DataLoader(
            test_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
        num_classes = len(train_dataset.classes)
    else:
        # read dataset
        dataset = torchvision.datasets.ImageFolder(root=dataset_root, transform=transform_train)

        train_dataset, test_dataset = torch.utils.data.random_split(dataset, [0.8, 0.2])

        # 训练集
        train_dataloader = data.DataLoader(
            train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)

        # 测试集
        test_dataloader = data.DataLoader(
            test_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
        num_classes = len(dataset.classes)

    return train_dataset, test_dataset, train_dataloader, test_dataloader, num_classes