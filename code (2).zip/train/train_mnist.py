import math
import sys
# 可以从父目录下查找模块
sys.path.append('../')

# from model.MDT.MDT import mdt_s_sm as train_model
# from model.T2T.T2T import T2t_vit_7 as train_model
# from model.Resnet.resnet import resnet18 as train_model
# from model.Swin.swin_transformer import swin_small_patch4_window7_224 as train_model
# from model.ViT.ViT import vit_base_patch16_224 as train_model
# from model.TNT.tnt import tnt_s_patch16_224 as train_model
from model.Swin.swin_transformer_v2 import swin_v2 as train_model

import os.path
import time
from datetime import datetime
from openpyxl import Workbook
from tqdm import tqdm
import argparse
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

import thop
import torch
import torchvision.transforms
import torch.utils.data as data
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast

def main(args):
    print(args)
    # 设置设备
    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    print('使用设备：{}'.format(device))

    # 数据读取与预处理

    # 数据集 数据归一化
    # 训练集 数据归一化
    transform_train = torchvision.transforms.Compose([
        torchvision.transforms.RandomResizedCrop(224),
        torchvision.transforms.RandomHorizontalFlip(),
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize([0.485], [0.229])
        # torchvision.transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    # 测试集 数据归一化
    transform_test = torchvision.transforms.Compose([
        torchvision.transforms.Resize(256),
        torchvision.transforms.CenterCrop(224),
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize([0.485], [0.229])
        # torchvision.transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    # 训练集
    train_dataset = torchvision.datasets.MNIST(
        root=args.dataset_root, train=True, download=False, transform=transform_train)
    train_dataloader = data.DataLoader(
        train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)

    # 测试集
    test_dataset = torchvision.datasets.MNIST(
        root=args.dataset_root, train=False, download=False, transform=transform_test)
    test_dataloader = data.DataLoader(
        test_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)

    # # 以json文件形式保存类别信息
    # # 获取类别信息
    # # 划分过的数据集跟没划分的数据集有些不一样呢 里面会多一个dataset出来 class_to_idx在这里面
    # data_list = train_dataset.class_to_idx  # {'class_name':id,....}
    # classes_dict = dict((val, key) for key, val in data_list.items())
    # # indent用于指定缩进级别 让json里面的格式好看些
    # # ensure_ascii=False 不要将非 ASCII 字符（如中文）转义为 \uXXXX 格式的 Unicode 转义序列。
    # json_str = json.dumps(classes_dict, indent=4, ensure_ascii=False)
    # # 保存json文件
    # with open('class_indices.json', 'w', encoding='utf-8') as json_file:
    #     json_file.write(json_str)
    num_classes = len(train_dataset.classes)

    # 模型加载
    model = train_model(num_classes)

    # 使用预训练权重也可以是继续之前中断的训练但要配合log使用
    # 如果存在预训练权重则载入
    if args.model_weight_path != "":
        if os.path.exists(args.model_weight_path):
            weights_dict = torch.load(args.model_weight_path, map_location=device)
            load_weights_dict = {k: v for k, v in weights_dict.items()
                                 if model.state_dict()[k].numel() == v.numel()}
            print(model.load_state_dict(load_weights_dict, strict=False))
        else:
            raise FileNotFoundError("not found weights file: {}".format(args.weights))

# log功能开发中
    # log... 需要保存的结果：模型参数量、flops、fps、mean_loss、accuracy
    # 检查是否有log文件夹 ../表示在父目录里找
    if not os.path.exists('../log'):
        # 没有就创建一个
        os.mkdir('../log')
    # 检查log下是否有当前模型对应的日志文件夹
    model_name = model.__class__.__name__
    if not os.path.exists(f'../log/{model_name}'):
        os.mkdir(f'../log/{model_name}')
    method_name = train_model.__name__
    if not os.path.exists(f'../log/{model_name}/{method_name}'):
        os.mkdir(f'../log/{model_name}/{method_name}')
    # 创建本次训练的日志文件夹 文件夹命名方式：train_数据集名称_年月日时分秒
    t = datetime.now() # 获取当前时间
    time_str = f'{t.year}-{t.month}-{t.day}_{t.hour}：{t.minute}：{t.second}'
    log_path = f'../log/{model_name}/{method_name}/train_{args.dataset_name}_{time_str}'
    os.mkdir(log_path)
    # 创建工作簿 模型性能、平均损失、top-1准确率
    wb = Workbook()
    performance_sheet = wb.create_sheet('performance')
    loss_sheet = wb.create_sheet('loss')
    accuracy_sheet = wb.create_sheet('accuracy')
    wb.remove(wb.active)
    sheet_names = wb.sheetnames
    wb.save(f'{log_path}/log.xlsx')

    # 是否冻结权重
    if args.freeze_layers:
        for name, para in model.named_parameters():
            # 除最后一个卷积层和全连接层外，其他权重全部冻结
            if ("features.top" not in name) and ("classifier" not in name):
                para.requires_grad_(False)
            else:
                print("training {}".format(name))

    # 各种设置的初始化
    loss_function = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=args.scheduler_size, gamma=args.gamma)
    scaler = GradScaler()
    # 在 PyTorch 中，CUDA 操作通常要求输入数据类型为 torch.float32
    model.to(device=device, dtype=torch.float32)

    # train
    loss_sheet.append(['轮次', '平均损失'])
    accuracy_sheet.append(['轮次', 'top-1准确率'])
    loss_list = [[], []]
    accuracy_list = [[], []]
    best_accuracy = 0.0
    for epoch in range(args.epochs):
        # train
        model, mean_loss = train_one_epoch(model, train_dataloader, loss_function, optimizer, device,
                                           scheduler, scaler, epoch, args.epochs)
        loss_sheet.append([epoch + 1, mean_loss])
        loss_list[0].append(epoch + 1)
        loss_list[1].append(mean_loss)

        # val
        if epoch % args.print_epoch == args.print_epoch - 1:
            accuracy = evaluate_one_epoch(model, test_dataloader, device, epoch,
                                          args.epochs, args.eval_size)
            accuracy_sheet.append([epoch + 1, accuracy])
            accuracy_list[0].append(epoch + 1)
            accuracy_list[1].append(accuracy)
            # 模型保存
            if accuracy >= best_accuracy:
                best_accuracy = accuracy
                torch.save(model.state_dict(), f'{log_path}/{model_name}_best.pth')
        # save
        wb.save(f'{log_path}/log.xlsx')

    torch.save(model.state_dict(), f'{log_path}/{model_name}_finish.pth')

    # predict
    predict_accuracy, fps = predict_one_epoch(model, test_dataloader, device)

    # 计算模型参数量、flops、fps
    test_input = torch.randn((1, 3, 224, 224), device=device)
    flops, params = thop.profile(model, (test_input,))

    print('flops: %.2f M, params: %.2f M, fps: %.2f 张/s, accuracy: %.2f％' % (flops / 1e6, params / 1e6, fps, predict_accuracy * 100))
    # 保存于日志
    performance_sheet.append(['Flops(M)', '模型参数量(M)', 'fps(张/s)', 'top-1准确率(%)', 'batch_size', 'epochs', 'lr', 'num_classes', 'scheduler_size', 'gamma'])
    performance_sheet.append([flops / 1e6, params / 1e6, fps, predict_accuracy, args.batch_size, args.epochs, args.lr, num_classes, args.scheduler_size, args.gamma])
    wb.save(f'{log_path}/log.xlsx')

    # 将平均损失和准确率绘制成图
    # mean_loss
    show_png(loss_list, 'epoch', 'mean_loss', log_path)

    # mean_loss
    show_png(accuracy_list, 'epoch', 'accuracy', log_path)

def show_png(data_list, x, y, log_path):
    x_min, x_max = min(data_list[0]), max(data_list[0])
    y_min, y_max = min(data_list[1]), max(data_list[1])
    dx = x_max * 0.2
    dy = (y_max - y_min) * 0.2
    plt.xlim(0, x_max + dx)  # 横纵坐标上下限
    plt.ylim(max((y_min - dy), 0), y_max + dy + 0.1)

    plt.xlabel(f'{x}')  # 标签
    plt.ylabel(f'{y}')
    plt.xticks(list(range(0, int(x_max + dx), math.ceil(x_max / 10))))
    plt.plot(data_list[0], data_list[1], linewidth=2.0)  # 绘制曲线
    plt.title(f'{y}')
    plt.savefig(f'{log_path}/{y}.png')
    plt.show()
    plt.clf()

def predict_one_epoch(model, predict_dataloader, device):
    model.eval()

    with torch.no_grad():
        true_predict_sum = 0
        predict_sum = 0
        compute_time_sum = 0
        predict_bar = tqdm(enumerate(predict_dataloader), desc='测试中...')
        for step, val_data in predict_bar:
            # 测试代码用
            if step == 2:
                break

            predict_bar.desc = f'测试中:第{step+1}/{len(predict_dataloader)}步'
            inputs, labels = val_data
            inputs, labels = inputs.to(device=device), labels.to(device=device)

            # fps
            torch.cuda.synchronize()
            start = time.time()
            outputs = model(inputs)  # outputs:(batch_size, classes)
            torch.cuda.synchronize()
            end = time.time()
            compute_time_sum += (end - start)

            # torch.max返回是(max_value,max_index) index表示类
            predict = torch.max(outputs, dim=1)[1]  # predict:(batch_size,1)
            # 更新预测正确总数
            true_predict_sum += torch.eq(predict, labels.to(device)).sum().cpu().item()
            # 更新预测总数
            predict_sum += labels.cpu().size(0)
        # 计算准确率
        accuracy = true_predict_sum / predict_sum
        # 计算fps
        fps = predict_sum / compute_time_sum
    return accuracy, fps

def evaluate_one_epoch(model, val_dataloader, device, epoch, epochs, eval_size):
    model.eval()

    with torch.no_grad():
        true_predict_sum = 0
        predict_sum = 0
        val_bar = tqdm(enumerate(val_dataloader), desc=f'验证中:第{epoch+1}/{epochs}轮')
        for step, val_data in val_bar:
            # 测试代码用
            if step == eval_size:
                break

            val_bar.desc = f'验证中:第{epoch+1}/{epochs}轮,第{step+1}/{len(val_dataloader)}步'
            inputs, labels = val_data
            inputs, labels = inputs.to(device=device), labels.to(device=device)

            outputs = model(inputs) # outputs:(batch_size, classes)
            # torch.max返回是(max_value,max_index) index表示类
            predict = torch.max(outputs, dim=1)[1]  # predict:(batch_size,1)
            # 更新预测正确总数
            true_predict_sum += torch.eq(predict, labels.to(device)).sum().cpu().item()
            # 更新预测总数
            predict_sum += labels.cpu().size(0)
            # 计算准确率
        accuracy = true_predict_sum / predict_sum
        print(f'*****第{epoch+1}/{epochs}轮 accuracy:{accuracy}*****')
    return accuracy

def train_one_epoch(model, train_dataloader, loss_function, optimizer,
                    device, scheduler, scaler, epoch, epochs):
    sum_loss = 0.0
    train_bar = tqdm(enumerate(train_dataloader), desc=f'训练中:第{epoch+1}/{epochs}轮训练中')
    for step, train_data in train_bar:
        # 测试代码用
        if step == 2:
            break

        train_bar.desc = f'训练中:第{epoch+1}/{epochs}轮,第{step+1}/{len(train_dataloader)}步'
        model.train()

        inputs, labels = train_data
        inputs, labels = inputs.to(device=device), labels.to(device=device)

        # 梯度归零
        optimizer.zero_grad()

        # 前向传播
        outputs = model(inputs)

        # 计算损失
        loss = loss_function(outputs, labels)
        loss.backward()
        optimizer.step()

        # 使用scaler.scale来缩放损失
        # scaler.scale(loss).backward()

        # 使用scaler.step和scaler.update来更新参数和缩放器状态
        # scaler.step(optimizer)
        # scaler.update()

        sum_loss += loss.cpu().item()

        # 学习率更新
        # scheduler.step()
    mean_loss = sum_loss / len(train_dataloader)
    print(f'第{epoch+1}/{epochs}轮 mean_loss:{mean_loss}')
    return model, mean_loss


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('--dataset_root', type=str, default=r'D:\File\Data_Set\MNIST')
    parser.add_argument('--batch_size', type=int, default=2)
    parser.add_argument('--epochs', type=int, default=2)
    parser.add_argument('--print_epoch', type=int, default=1)
    parser.add_argument('--eval_size', type=int, default=2)
    parser.add_argument('--train_scale', type=float, default=0.34)
    parser.add_argument('--test_scale', type=float, default=0.33)

    # parser.add_argument('--dataset_root', type=str, default=r'/home/featurize/data')
    # parser.add_argument('--batch_size', type=int, default=32)
    # parser.add_argument('--epochs', type=int, default=50)
    # parser.add_argument('--print_epoch', type=int, default=5)
    # parser.add_argument('--eval_size', type=int, default=2)
    # parser.add_argument('--train_scale', type=float, default=0.7)
    # parser.add_argument('--test_scale', type=float, default=0.2)

    parser.add_argument('--model_weight_path', type=str, default='')
    parser.add_argument('--dataset_name', type=str, default='mnist')

    parser.add_argument('--lr', type=float, default=3e-4)
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--freeze_layers', type=bool, default=False)
    parser.add_argument('--scheduler_size', type=int, default=1000)
    parser.add_argument('--gamma', type=float, default=0.8)

    opt = parser.parse_args()
    main(opt)