import torch
import math


def get_2d_positional_encoding(height, width, d_model):
    """
    生成二维位置编码矩阵（优化版）

    参数:
    - height: 特征图的高度
    - width: 特征图的宽度
    - d_model: 位置编码的维度（通常是特征向量的维度，应为偶数）

    返回:
    - pos_encoding: (height, width, d_model)的二维位置编码矩阵
    """

    # 创建x和y的位置矩阵
    pos_x = torch.arange(width).unsqueeze(0).expand(height, -1).float()
    pos_y = torch.arange(height).unsqueeze(1).expand(-1, width).float()

    # 计算每个维度的分母（10000^(2i/d_model) 和 10000^(2(i+1)/d_model)）
    div_term = torch.arange(0, d_model, 2).float() / (d_model / 2.0)  # 0, 1, 2, ..., (d_model/2-1)
    scale = 10000.0 ** (div_term / d_model)

    # 使用广播机制计算正弦和余弦值
    pos_x_scaled = pos_x.unsqueeze(2) / scale.unsqueeze(0).unsqueeze(0)
    pos_y_scaled = pos_y.unsqueeze(2) / scale.unsqueeze(0).unsqueeze(1)

    # 初始化位置编码矩阵
    pos_encoding = torch.zeros(height, width, d_model).float()

    # 放置正弦和余弦值
    pos_encoding[:, :, 0::2] = torch.sin(pos_x_scaled)  # 偶数索引位置放置正弦值
    pos_encoding[:, :, 1::2] = torch.cos(pos_y_scaled)  # 奇数索引位置放置余弦值

    return pos_encoding


# 示例用法
height, width = 56, 56  # 特征图的高度和宽度
d_model = 2  # 位置编码的维度（假设为偶数）

pos_encoding = get_2d_positional_encoding(height, width, d_model)
print(pos_encoding.shape)  # 输出: torch.Size([64, 64, 128])