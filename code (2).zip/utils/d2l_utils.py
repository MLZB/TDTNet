import copy
import os
import random
import sys
import typing
from typing import Type, TypeVar
import torch
import torch.nn as nn
import torchvision
import torch.utils.data as data
import torch.optim.optimizer as optimizer
import numpy as np
import openpyxl
from tqdm import tqdm
import shutil

Loss = TypeVar('Loss',bound=nn.Module)

# --------------------数据集相关方法类方法--------------------
# 全部以dataset开头

# 根据路径读取图片数据集
# root 路径
# weight 改变图片的宽
# height 改变图片的高
# batch_size 批量
# split 划分数据集的比例 输入为划分后第二个数据集的占比 0表示不划分
# transform 数据处理
# transform_list数据处理列表
# return 数据加载器 数据集
def dataset_of_image_read_by_root(root:str,
                                  batch_size:int,
                                  width:int = None,
                                  height:int = None,
                                  split=0,
                                  transform:torchvision.transforms.Compose = None,
                                  transform_list:typing.List[torchvision.transforms.Compose] = None):
    """
    :param root: str 路径
    :param batch_size: int 批量
    :param width: int 改变图片的宽
    :param height: int 改变图片的高
    :param split: 划分数据集的比例 输入为划分后第二个数据集的占比 0表示不划分
    :param transform: torchvision.transforms.Compose 数据处理
    :param transform_list: typing.List[torchvision.transforms.Compose] transform_list数据处理列表
    :return: 数据加载器 数据集
    """
    # 图片预处理
    # 判断有没有传进transform 没传就自己声明
    if not transform:
        transform = torchvision.transforms.Compose([
            torchvision.transforms.ToTensor(),  # 图片张量化
            torchvision.transforms.Normalize(
                (0.5, 0.5, 0.5),
                (0.5, 0.5, 0.5)
            ),  # 标准正态化
            torchvision.transforms.Resize((width, height))  # 宽高改变
        ])

    # 根据路径找到图片数据集
    assert os.path.exists(root), 'file:{}不存在'.format(root)
    dataset = torchvision.datasets.ImageFolder(root,transform=transform)
    # 判断是否需要划分数据集
    if split:
        dataset_copy = torchvision.datasets.ImageFolder(root,transform=transform)
        # 划分数据集
        size1 = int(split * len(dataset))
        # size2 = len(dataset) - size1
        # 使用索引来创建两个新的Subset对象
        indices = list(range(len(dataset)))
        # 乱序 原地操作
        random.shuffle(indices)
        # 划分
        dataset_list1 = indices[:size1]
        dataset_list2 = indices[size1:]

        # 使用不同的变换创建两个新的数据集
        # Subset只提供索引 所以要保证两个划分后的数据集中的transform不共用 就必须用两个dataset
        dataset1 = data.Subset(dataset, dataset_list1)
        dataset2 = data.Subset(dataset_copy, dataset_list2)
        # 过时 dataset1,dataset2 = data.random_split(dataset,[int(split*len(dataset)),len(dataset)-int(split*len(dataset))])

        # 选择数据处理方式
        # 划分数据集后 dataset1,dataset2中会有个dataset transform在这个里面
        # # 由于random_split只是根据索引将数据集分成两个子集，这两个子集仍然会共享相同的transform定义。没错，都指向了dataset的transform
        if transform_list:
            dataset1.dataset.transform,dataset2.dataset.transform = transform_list[0],transform_list[1]
        # 数据集加载
        dataset_loader1 = data.DataLoader(dataset=dataset1,batch_size=batch_size,
                                                 shuffle=True,num_workers=0)
        dataset_loader2 = data.DataLoader(dataset=dataset2,batch_size=batch_size,
                                                 shuffle=True,num_workers=0)
        return dataset_loader1,dataset_loader2,dataset1,dataset2

    # 数据集加载
    dataset_loader = data.DataLoader(dataset=dataset,batch_size=batch_size,
                                     shuffle=True,num_workers=0)

    return dataset_loader,dataset

# 对分类数据集进行划分
def dataset_of_classification_split(data_root:str,
                                    target_root:str = None,
                                    train_scale:float = 0.8,
                                    val_scale:float = 0.0,
                                    test_scale:float = 0.2):
    """
    :param data_root:str 数据集的根目录
    :param target_root:str 指定划分数据集的保存路径
    :param train_scale: float 训练集划分比例
    :param val_scale: float 验证集集划分比例
    :param test_scale: float 测试集划分比例
    :return: train_root,val_root,test_root
    """
    # 获取当前路径
    # [:]保证path和os.getcwd()解绑而不指向同一个对象 避免path随着os.getcwd()的改变而改变
    parent_path = os.getcwd()
    # 判断输入有无问题
    assert os.path.exists(data_root), 'file:{}不存在'.format(data_root)
    if target_root:
        assert os.path.exists(target_root), 'file:{}不存在'.format(target_root)
    assert train_scale + val_scale + test_scale == 1.0, '输入的scale不正确'

    print('开始划分数据集')

    # 读取全部图片数据
    # 这里默认的data_root是这样子的
    # data_root:
    #   class1:
    #       1.jpg
    #       2.jpg
    #   class2:
    #       ...
    # 第一步 获取所有的class文件夹和数据
    class_name_list = [] # 保存类别名称信息
    class_path_list = [] # 保存每一类文件夹的路径
    data_path_list_list = [] # 按类保存所有数据路径的列表
    data_number_list = [] # 每一类数据的数量
    data_name_list_list = [] # 按类保存所有数据文件名的列表
    # 遍历文件夹中所有的文件夹和文件
    for filename in tqdm(os.listdir(data_root),desc='遍历文件中'):
        # 判断是否为文件夹
        class_path = os.path.join(data_root,filename)
        if os.path.isdir(class_path):
            # 保存类的信息
            class_name_list.append(filename)
            class_path_list.append(class_path)

            # 保存数据的信息
            data_path_list = os.listdir(class_path)
            # 打乱data_path_list
            random.shuffle(data_path_list)
            # copy
            data_name_list = copy.copy(data_path_list)
            # 使用copy解决data_name_list里的对象会因为下面的操作也发生改变的问题
            data_name_list_list.append(data_name_list)
            for i,data_name in enumerate(data_path_list):
                data_path_list[i] = os.path.join(class_path,data_name)
            data_path_list_list.append(data_path_list)
            data_number_list.append(len(data_path_list))

    data_sum = sum(data_number_list)  # 数据总量
    # 计划划分数据量
    train_dataset_number = int(data_sum * train_scale)
    val_dataset_number = int(data_sum * val_scale)
    test_dataset_number = data_sum - train_dataset_number - val_dataset_number

    # 创建划分后数据要放入的文件夹
    # 判断是否有指定目录 没有就令data_root的父目录为target_root
    if not target_root:
        os.chdir(data_root)
        target_root = os.pardir
    # 令target_root为当前工作目录
    os.chdir(target_root)
    # 开始创建文件夹
    target_root_list = ['train','val','test']
    # 已经存在就删掉
    for path in target_root_list:
        dir_path = os.path.join(target_root,path)
        if os.path.exists(dir_path):
            # 删除文件夹及里面所有的数据
            shutil.rmtree(dir_path)
    os.mkdir(target_root_list[0])
    os.mkdir(target_root_list[1])
    os.mkdir(target_root_list[2])
    # 已经向新文件夹转移的数据量
    train_dataset_already = 0
    val_dataset_already = 0
    test_dataset_already = 0
    sum_dataset_already = 0
    for folder_name in tqdm(target_root_list,desc='划分数据中'):
        # 更新当前操作目录
        os.chdir(os.path.join(target_root,folder_name))
        # 根据数据分类创建文件夹 获取原数据目录下类文件夹的路径
        # class_name str
        # class_path str
        # data_path_list List(str) 都是绝对路径
        # data_number int
        # data_name_list List(str) 和data_path一一对应
        # 最后一个类目录单独处理保证数目正确
        for i in range(len(class_name_list) - 1):
            class_name, data_path_list, data_number, data_name_list = class_name_list[i],data_path_list_list[i],data_number_list[i],data_name_list_list[i]

            # 计算数据的划分
            # 当前列表的总数据量
            data_list_sum = len(data_path_list)
            # 当前类中的训练集、验证集、测试集的数据应有量
            class_train_number = int(data_list_sum * train_scale)
            class_val_number = int(data_list_sum * val_scale)
            class_test_number = data_list_sum - class_train_number - class_val_number

            # 根据类名创建当前类的文件夹
            os.mkdir(class_name)
            # 更新当前工作目录为新建的当前的类的文件夹
            os.chdir(os.path.join(os.getcwd(),class_name))
            # 根据当前['train','val','test']来判断下一步操作
            if folder_name == 'train':
                # [:class_train_number]
                # zip 函数通常用于这种情况，它能够将两个（或更多）列表“压缩”在一起，使得在迭代时可以同时获取两个列表中的对应元素
                for src_data_path, src_data_name in zip(data_path_list[:class_train_number],data_name_list[:class_train_number]):
                    # 将图片复制过去
                    shutil.copy(src_data_path,os.path.join(os.getcwd(),src_data_name))
                # 统计整体数据集中三种数据已将划分的量
                train_dataset_already += class_train_number
                sum_dataset_already += class_train_number
            elif folder_name == 'val':
                # [class_train_number:(class_train_number+class_val_number)]
                for src_data_path, src_data_name in zip(data_path_list[class_train_number:(class_train_number+class_val_number)],data_name_list[class_train_number:(class_train_number+class_val_number)]):
                    # 将图片复制过去
                    shutil.copy(src_data_path,os.path.join(os.getcwd(),src_data_name))
                # 统计整体数据集中三种数据已将划分的量
                val_dataset_already += class_val_number
                sum_dataset_already += class_val_number
            else:
                # [(class_train_number+class_val_number):]
                for src_data_path, src_data_name in zip(data_path_list[(class_train_number+class_val_number):],data_name_list[(class_train_number+class_val_number):]):
                    # 将图片复制过去
                    shutil.copy(src_data_path,os.path.join(os.getcwd(),src_data_name))
                # 统计整体数据集中三种数据已将划分的量
                test_dataset_already += class_test_number
                sum_dataset_already += class_test_number
            # 返回到folder_name目录
            os.chdir(os.path.join(target_root,folder_name))

        # 最后一个类
        class_name, data_path_list, data_number, data_name_list = class_name_list[-1], data_path_list_list[-1],data_number_list[-1],data_name_list_list[-1]

        # 计算数据的划分
        # 当前类中的训练集、验证集、测试集的数据应有量
        # 由于前面的类划分时用int取整会去掉小数，这里把train的量用data_list_sum去减来求会减小划分误差
        class_train_number = train_dataset_number - train_dataset_already
        class_val_number = val_dataset_number - val_dataset_already
        class_test_number = test_dataset_number - test_dataset_already

        # 根据类名创建当前类的文件夹
        os.mkdir(class_name)
        # 更新当前工作目录为新建的当前的类的文件夹
        os.chdir(os.path.join(os.getcwd(), class_name))

        # 根据当前['train','val','test']来判断下一步操作
        if folder_name == 'train':
            # [:class_train_number]
            for src_data_path, src_data_name in zip(data_path_list[:class_train_number], data_name_list[:class_train_number]):
                # 将图片复制过去
                shutil.copy(src_data_path, os.path.join(os.getcwd(), src_data_name))
            # 统计整体数据集中三种数据已将划分的量
            train_dataset_already += class_train_number
            sum_dataset_already += class_train_number
        elif folder_name == 'val':
            # [class_train_number:(class_train_number+class_val_number)]
            for src_data_path, src_data_name in zip(data_path_list[class_train_number:(class_train_number+class_val_number)], data_name_list[class_train_number:(class_train_number+class_val_number)]):
                # 将图片复制过去
                shutil.copy(src_data_path, os.path.join(os.getcwd(), src_data_name))
            # 统计整体数据集中三种数据已将划分的量
            val_dataset_already += class_val_number
            sum_dataset_already += class_val_number
        else:
            # [(class_train_number+class_val_number):]
            for src_data_path, src_data_name in zip(data_path_list[(class_train_number+class_val_number):], data_name_list[(class_train_number+class_val_number):]):
                # 将图片复制过去
                shutil.copy(src_data_path, os.path.join(os.getcwd(), src_data_name))
            # 统计整体数据集中三种数据已将划分的量
            test_dataset_already += class_test_number
            sum_dataset_already += class_test_number

        # 返回到folder_name目录
        os.chdir(os.path.join(target_root, folder_name))

    print('完成数据集划分')
    print('数据集保存在目录：{}下'.format(target_root))
    print('数据集中共{}类，数据量为{}'.format(len(class_name_list),data_sum))
    print('划分后训练集、验证集、测试集数据量如下：')
    print('train:{},val:{},predict:{},total:{}'.format(train_dataset_already,val_dataset_already,test_dataset_already,sum_dataset_already))

    # 训练集、验证集、测试集路径
    train_root = os.path.join(target_root,'train')
    val_root = os.path.join(target_root, 'val')
    test_root = os.path.join(target_root, 'test')

    # 恢复路径为调用该函数的对象的目录
    os.chdir(parent_path)
    return train_root,val_root,test_root

# --------------------网络训练相关方法--------------------
# 全部以train开头

# 分类网络训练并保存
# model 要训练的分类网络模型
# loss_function 损失函数
# optim 优化器，已经实例化的，实例化时已经规定了参数网络和学习率
# epochs 训练轮次
# train_loader 训练集加载器
# val_loader 验证集加载器 默认为None可不写
# save_path 模型存储路径
# print_epoch 打印轮次
# device 设备
# return 训练好的模型
def train_classification_net(model:nn.Module,
                             loss_function:Loss,
                             optim:optimizer.Optimizer,
                             epochs:int,
                             save_path:str,
                             save_finish_path:str,
                             train_loader:data.DataLoader,
                             val_loader:data.DataLoader = None,
                             print_epoch=0,
                             device=torch.device('cpu'),
                             outputs_weight:list=None):
    """
    :param model: nn.Module 要训练的分类网络模型
    :param loss_function: Loss = TypeVar('Loss',bound=nn.Module) 损失函数
    :param optim: optimizer.Optimizer 优化器，已经实例化的，实例化时已经规定了参数网络和学习率
    :param epochs: int 训练轮次
    :param save_path: str 模型存储路径
    :param train_loader: data.DataLoader 训练集加载器
    :param val_loader: data.DataLoader = None 验证集加载器 默认为None可不写
    :param print_epoch: 0 打印轮次
    :param device: None 设备
    :return: model:nn.Module 训练好的模型
    """

    # 模型置于设备上 默认cpu
    model = model.to(device)

    # 根据epochs设定训练轮次
    best_accuracy = 0.0
    epoch_bar = tqdm(range(epochs))
    for epoch in epoch_bar:
        sum_loss = 0.0
        # 每一步从train_loader读取一个批次的数据
        # step是当前步数
        for step, train_data in enumerate(train_loader,start=0):
            # train
            model.train()
            # data中包含数据和标签，这里分开
            inputs, labels = train_data

            # 将数据置于GPU
            if device != torch.device('cpu'):
                inputs, labels = inputs.to(device), labels.to(device)

            # 梯度归零
            optim.zero_grad()
            # 前向传播
            outputs = model(inputs)
            # 计算损失
            # 判断是否只有一个返回值，使用辅助分类器时会返回一个包含多个分类器结果的元组
            loss = 0.0
            if isinstance(outputs,tuple):
                assert outputs_weight is not None and (len(outputs_weight) >= len(outputs)),'outputs_weight不正确'
                for i,outputs_x in enumerate(outputs):
                    loss += loss_function(outputs_x,labels) * outputs_weight[i]
            else:
                loss = loss_function(outputs,labels)
            # 累加损失
            sum_loss += loss.item()
            # 反向传播
            loss.backward()
            # 参数迭代
            optim.step()

        # eval
        model.eval() #关闭dropout
        # 打印当前步的训练情况
        # 判断是否需要打印
        if val_loader and print_epoch:
            if epoch % print_epoch == print_epoch - 1:
                # 关闭梯度训练模式
                with torch.no_grad():
                    true_predict_sum = 0
                    predict_sum = 0
                    # leave=False 进度完成过后进度条消失解决进度条显示异常问题
                    for val_data in tqdm(val_loader, file=sys.stdout,desc='验证中'):
                        val_input,val_label = val_data
                        outputs = model(val_input.to(device))  # outputs:(batch_size,class_number)
                        # torch.max返回是(max_value,max_index) index表示类
                        predict = torch.max(outputs, dim=1)[1]  # predict:(batch_size,1)
                        # 更新预测正确总数
                        true_predict_sum += torch.eq(predict, val_label.to(device)).sum().item()
                        # 更新预测总数
                        predict_sum += val_label.size(0)
                    # 计算准确率
                    accuracy = true_predict_sum / predict_sum

                    # 打印
                    epoch_bar.desc = '轮次:%d/%d,  平均损失:%.3f, 验证集准确率:%.3f' % (epoch + 1, epochs, sum_loss / print_epoch, accuracy)
                # 判断是否更新模型保存文件
                if accuracy > best_accuracy:
                    best_accuracy = accuracy
                    torch.save(model.state_dict(), save_path)
    print('训练结束')

    # 保存训练结果
    if not (val_loader and print_epoch):
        torch.save(model.state_dict(),save_path)
    torch.save(model.state_dict(), save_finish_path)
    print('模型已保存至' + save_path)

    return model

# --------------------网络预测相关方法--------------------
# 全部以predict开头

# 分类网络结果预测并保存
# dataset_loader 预测数据集的加载器
# model 模型
# save_path 结果保存路径
# classes 标签名称
# device 设备
# return result_list,label_list
def predict_of_classification_net(dataset_loader:data.DataLoader,
                                  model:nn.Module,
                                  save_path:str,
                                  classes:typing.Union[typing.Tuple,typing.List],
                                  device=None):
    """
    :param dataset_loader: data.DataLoader 预测数据集的加载器
    :param model: nn.Module 模型
    :param save_path: str 结果保存路径
    :param classes: typing.Union[typing.Tuple,typing.List] 标签名称
    :param device: None 设备
    :return: result_list,label_list
    """
    # 创建表格
    workbook = openpyxl.Workbook()
    # 获取默认拥有的第一张工作表
    worksheet = workbook.active
    # 第一行写表头
    worksheet.append(['序号','预测值','标签'])

    # 模型置于GPU
    if device:
        model = model.to(device)

    result_list = []  # 保存结果
    label_list = []  # 保存真实标签
    # 按批次预测
    for step,predict_data in enumerate(dataset_loader,start=1):
        # data中包含数据和标签，这里分开
        inputs, labels = predict_data
        label_list.extend(labels.numpy())

        # 数据置于GPU
        if device:
            inputs, labels = inputs.to(device), labels.to(device)

        # 关闭训练模式
        model.eval()
        with torch.no_grad():
            outputs = model(inputs) # outputs:(batch_size,class_number)
            # torch.max返回是(max_value,max_index) index表示类
            # NumPy不支持直接在GPU上处理数据
            predicts = torch.max(outputs,dim=1)[1].cpu().numpy() # predicts:(batch_size,1)
            # extend是一个原地操作 直接修改result而没有返回值
            result_list.extend(predicts)

    # result_list:(数据量,1)     label_list:(数据量,1)

    # 将结果写入表格
    for i in range(len(label_list)):
        # 表格中是以1为第一个索引所以加2
        worksheet.cell(i + 2, 1, i + 1)
        worksheet.cell(i + 2, 2, classes[result_list[i]]) # row column value
        worksheet.cell(i + 2, 3, classes[label_list[i]])

    # 计算结果准确率
    # numpy数组直接比较可以得到布尔值列表 python自带的列表不行
    accuracy = sum(np.array(result_list) == label_list)/len(label_list)
    worksheet.append(['准确率',accuracy])

    # 保存表格
    workbook.save(save_path)
    return result_list,label_list