import sys
# 可以从父目录下查找模块
sys.path.append('../')

# from model.CrossViT.crossvit import crossvit_15_224 as train_model
# from model.DeiT.models import deit_tiny_patch16_224 as train_model
# from model.EfficientNet.EfficientNetV1 import efficientnet_b0 as train_model
# from model.EfficientNet.EfficientNetV2 import efficientnetv2_s as train_model
# from model.MDT.MDT13 import mdt_large as train_model
# from model.MDT.TDT7 import tdt_large as train_model
from model.MDT.TDTNet4 import tdt_small as train_model
# from model.MobileNet.model_v2 import MobileNetV2 as train_model
# from model.MobileNet.model_v3 import mobilenet_v3_large as train_model
# from model.PVT.pvt import pvt_tiny as train_model
# from model.PVT.pvt_v2 import pvt_v2_b1 as train_model
# from model.Resnet.resnet import resnet18 as train_model
# from model.ScaleNet.ScaleNet7 import model_test as train_model
# from model.Swin.swin_transformer import swin_tiny_patch4_window7_224 as train_model
# from model.Swin.swin_transformer_v2 import swin_v2 as train_model
# from model.T2T.T2T import T2t_vit_13 as train_model
# from model.TNT.tnt import tnt_t_patch16_224 as train_model
# from model.ViT.ViT import vit_base_patch16_224 as train_model

import thop
import torch
import time

device = torch.device('cuda')

model = train_model(num_classes=10)
model.to(device)

# 计算模型参数量、flops、fps
test_input = torch.randn((1, 3, 224, 224), device=device)
flops, params = thop.profile(model, (test_input,))

step = 2
time_sum = 0
for i in range(step):
    # fps
    torch.cuda.synchronize()
    start = time.time()
    outputs = model(test_input)  # outputs:(batch_size, classes)
    torch.cuda.synchronize()
    end = time.time()
    time_sum += (end - start)
fps = step / time_sum

print('flops: %.2f M, params: %.2f M, fps: %.2f 张/s' % (flops / 1e6, params / 1e6, fps))

