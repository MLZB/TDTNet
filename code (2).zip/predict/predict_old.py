import json
import os.path
import argparse

import torch
import torchvision.transforms

from model1 import model_test
import d2l_utils

def main(args):
    # 设置设备
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    # 获取模型
    model = model_test()
    # 加载参数
    model_path = args.model_path
    assert os.path.exists(model_path), 'file:{}不存在'.format(model_path)
    # strict=False令导入模型参数时不严格 因为验证的模型中没有辅助分类器时所以模型不同了
    missing_keys,unexpected_keys = model.load_state_dict(torch.load(model_path,map_location=device),strict=False)
    # 标签名称
    json_path = 'class_indices.json'
    assert os.path.exists(json_path),'file:{}不存在'.format(json_path)
    with open(json_path,'r',encoding='utf-8') as f:
        classes_dict = json.load(f)
    # 字典转元组
    classes = tuple(classes_dict.values())
    # classes = ('北', '宾', '丙', '并', '承', '朿', '从', '凤', '夫', '福')

    # 获取预测数据集加载器
    predict_dataset_loader,dataset = d2l_utils.dataset_of_image_read_by_root(args.data_root,
                                                                             batch_size=args.batch_size,
                                                                             transform=torchvision.transforms.Compose([
                                                                                torchvision.transforms.Resize(256),
                                                                                torchvision.transforms.CenterCrop(224),
                                                                                torchvision.transforms.ToTensor(),
                                                                                torchvision.transforms.Normalize([0.485, 0.456, 0.406],
                                                                                                                 [0.229, 0.224, 0.225])
                                                                                ]))
    # 获取预测数据集加载器 云GPU用
    # predict_dataset_loader, dataset = d2l_utils.dataset_of_image_read_by_root(
    #     r'/home/featurize/data/Oracle_predict_small',
    #     batch_size=32,
    #     transform=torchvision.transforms.Compose([
    #         torchvision.transforms.Resize(256),
    #         torchvision.transforms.CenterCrop(224),
    #         torchvision.transforms.ToTensor(),
    #         torchvision.transforms.Normalize([0.485, 0.456, 0.406],
    #                                          [0.229, 0.224, 0.225])
    #     ]))

    result_list, label_list = d2l_utils.predict_of_classification_net(dataset_loader=predict_dataset_loader,
                                                                      model=model,
                                                                      save_path=args.save_path,
                                                                      classes=classes,
                                                                      device=device)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()


    parser.add_argument('--model_path', type=str,default='MultipleDimensionTransformer_finish.pth')
    parser.add_argument('--save_path', type=str, default='./result.xlsx')
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--num_classes', type=int, default=10)

    parser.add_argument('--batch_size', type=int, default=2)
    parser.add_argument('--data_root', type=str,
                        default=r'D:\File\python_project\image_detection _by_deep_learning\Dataset\Oracle\Oracle_dataset_split\test')

    # parser.add_argument('--batch_size', type=int, default=32)
    # parser.add_argument('--data_root', type=str,
    #                     default=r'/home/featurize/data/Oracle_predict_small')

    opt = parser.parse_args()
    main(opt)